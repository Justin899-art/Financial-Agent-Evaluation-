"""Regression tests for failures catalogued in reports/failure_analysis.md."""

import pytest


@pytest.mark.skip(reason="stub")
def test_placeholder():
    """Replace with real tests."""
