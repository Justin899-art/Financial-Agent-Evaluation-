"""Integration tests for the FastAPI endpoints."""

import pytest


@pytest.mark.skip(reason="stub")
def test_placeholder():
    """Replace with real tests."""
