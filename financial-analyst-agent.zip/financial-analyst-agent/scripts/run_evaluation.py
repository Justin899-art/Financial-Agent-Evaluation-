"""Run the evaluation suite over datasets/ and write results to reports/."""
