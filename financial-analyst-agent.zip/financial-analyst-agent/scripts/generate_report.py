"""Generate reports/evaluation_report.md and reports/failure_analysis.md from evaluation results."""
