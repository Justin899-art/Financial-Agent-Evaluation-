"""Validate datasets/*.jsonl against datasets/schemas/task_schema.json."""
