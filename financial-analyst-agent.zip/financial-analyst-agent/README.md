# Financial Analyst Agent

Evidence-grounded financial document analyst agent with a built-in evaluation framework.

## Scope

- **In scope:** document-grounded QA, metric extraction, validated calculations with page-level citations
- **Out of scope:** web-scale research, investment recommendations, trading, predictions

## Evaluation

Answer correctness, faithfulness, citation accuracy, schema adherence, tool selection,
error recovery, latency, and cost. See `src/fin_agent/evaluation/` and `reports/`.

## Quickstart

```bash
pip install -e ".[dev]"
pytest
```
