"""Loads financial documents and their extracted pages and tables."""
