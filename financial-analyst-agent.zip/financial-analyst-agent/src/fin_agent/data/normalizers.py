"""Normalizes units, currencies, scales, and fiscal periods."""
