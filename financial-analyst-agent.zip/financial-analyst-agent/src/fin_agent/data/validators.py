"""Validates loaded data: required fields, units, periods."""
