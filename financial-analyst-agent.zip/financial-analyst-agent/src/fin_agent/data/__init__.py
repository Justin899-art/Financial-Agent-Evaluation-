"""Loading, validating, and normalizing financial document data."""
