"""Evidence-grounded financial document analyst agent."""
