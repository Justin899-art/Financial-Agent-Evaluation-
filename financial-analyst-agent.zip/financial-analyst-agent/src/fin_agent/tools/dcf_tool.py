"""Discounted cash flow valuation tool: free cash flow projection, WACC, terminal value, equity value."""
