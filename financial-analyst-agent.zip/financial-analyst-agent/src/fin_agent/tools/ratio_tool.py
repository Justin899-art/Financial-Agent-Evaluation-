"""Financial ratio calculations: liquidity, leverage, profitability, efficiency."""
