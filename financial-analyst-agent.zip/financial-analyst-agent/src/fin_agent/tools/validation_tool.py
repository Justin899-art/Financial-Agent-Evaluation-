"""Validates extracted figures and calculation inputs: units, periods, sign conventions, reconciliation checks."""
