"""Transparent forecasting tool: growth-rate and driver-based projections."""
