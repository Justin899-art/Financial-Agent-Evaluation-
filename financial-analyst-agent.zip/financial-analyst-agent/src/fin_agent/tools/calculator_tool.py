"""General-purpose arithmetic tool for precise, auditable calculations."""
