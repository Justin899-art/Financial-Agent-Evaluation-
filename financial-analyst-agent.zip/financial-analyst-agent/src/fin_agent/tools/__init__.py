"""Deterministic, validated financial calculation tools exposed to the agent."""
