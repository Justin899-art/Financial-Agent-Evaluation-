"""Structured logging configuration."""
