"""Latency, token usage, cost, and error-rate metrics."""
