"""FastAPI service exposing evaluations and reports."""
