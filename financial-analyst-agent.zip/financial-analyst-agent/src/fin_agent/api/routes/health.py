"""Health check endpoint."""
