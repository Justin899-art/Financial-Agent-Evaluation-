"""System and task prompts for the financial analyst agent."""
