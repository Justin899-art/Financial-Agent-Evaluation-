"""Core agent loop: plans, calls tools, and grounds answers in source documents with page-level citations."""
