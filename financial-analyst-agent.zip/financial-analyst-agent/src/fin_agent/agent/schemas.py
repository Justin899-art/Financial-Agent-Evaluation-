"""Pydantic schemas for agent inputs, tool calls, answers, and citations."""
