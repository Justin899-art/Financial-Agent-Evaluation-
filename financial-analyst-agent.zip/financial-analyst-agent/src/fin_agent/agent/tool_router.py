"""Selects and dispatches tools (DCF, ratio, forecast, validation, calculator) for a given task."""
