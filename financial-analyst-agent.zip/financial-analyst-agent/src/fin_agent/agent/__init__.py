"""Agent orchestration: prompting, tool routing, structured outputs."""
