"""Formats agent output into the validated answer schema with citations."""
