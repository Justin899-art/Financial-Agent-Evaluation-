"""Scores tool selection, call ordering, and error recovery across the agent trajectory."""
