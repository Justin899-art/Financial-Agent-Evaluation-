"""Checks scope adherence: declines investment recommendations, trading advice, and predictions."""
