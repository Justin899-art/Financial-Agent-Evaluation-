"""Evaluation framework: runs tasks and scores the agent on correctness, grounding, safety, and trajectory."""
