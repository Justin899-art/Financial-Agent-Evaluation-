"""Clusters and summarizes failed tasks by failure mode for reports/failure_analysis.md."""
