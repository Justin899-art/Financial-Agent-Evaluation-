"""Runs evaluation tasks from datasets/ against the agent and records outputs and traces."""
