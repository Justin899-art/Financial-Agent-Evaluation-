"""Scores reasoning quality and adherence to the expected calculation method."""
