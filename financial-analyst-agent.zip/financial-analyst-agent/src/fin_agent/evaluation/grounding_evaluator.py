"""Scores faithfulness to source documents and page-level citation accuracy."""
