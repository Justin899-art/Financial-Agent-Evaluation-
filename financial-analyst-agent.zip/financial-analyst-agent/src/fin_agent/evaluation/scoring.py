"""Aggregates evaluator results into per-task and overall scores, including latency and cost."""
