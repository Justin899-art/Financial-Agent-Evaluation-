"""Scores numerical answer correctness against reference answers within tolerance."""
